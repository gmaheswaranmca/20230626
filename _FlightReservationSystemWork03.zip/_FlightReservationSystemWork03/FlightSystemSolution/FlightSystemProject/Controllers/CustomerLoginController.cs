﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FlightSystemProject.Models;

using System.Web.Security;
namespace FlightSystemProject.Controllers
{
    [AllowAnonymous]
    public class CustomerLoginController : Controller
    {
        private FlightSystemDbContext context = new FlightSystemDbContext();//ii
        
        // GET: CustomerLogin
        
        public ActionResult Index(string error="")
        {
            if (User.Identity.IsAuthenticated && 
                Session["App"] != null && 
                ((string)Session["App"]).Equals("CustomerApp"))
            {
                FormsAuthentication.RedirectFromLoginPage(User.Identity.Name, false);
            }
            if (!error.Equals(String.Empty))
            {
                ModelState.AddModelError("", error);
            }
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Index(Customer formCustomer)
        {

            if (!ModelState.IsValid)
            {
                return View(formCustomer);
            }

            var oldCustomer = (from a in context.Customers
                            where a.Username.Equals(formCustomer.Username) && a.Password.Equals(formCustomer.Password)
                            select a).SingleOrDefault();
            if(oldCustomer == null)
            {
                ModelState.AddModelError("", "Invalid Username / Password");
                return View(formCustomer);
            }
            
            //Session["Username"] = oldCustomer.Username;
            FormsAuthentication.SetAuthCookie(oldCustomer.Username, false);
            Session["App"] = "CustomerApp";
            Session["UserId"] = oldCustomer.CustomerId;
            return RedirectToAction("Index","Booking");
        }

        [Authorize]
        public ActionResult Logout()
        {
            //Session["App"] = null;
            Session["UserId"] = null;
            Session["Username"] = null;
            FormsAuthentication.SignOut();
            return RedirectToAction("Index");
        }
        
        public ActionResult Register()
        {
            var newCustomer = new Customer();
            newCustomer.Name = string.Empty;
            newCustomer.MobileNumber = string.Empty;
            newCustomer.Username = string.Empty;
            newCustomer.Password = string.Empty;
            return View(newCustomer);
        }
        
        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Register(Customer formCustomer)
        {

            if (!ModelState.IsValid)
            {
                return View(formCustomer);
            }

            var newCustomer = new Customer();
            newCustomer.Name = formCustomer.Name;
            newCustomer.MobileNumber = formCustomer.MobileNumber;
            newCustomer.Username = formCustomer.Username;
            newCustomer.Password = formCustomer.Password;

            context.Customers.Add(newCustomer);
            context.SaveChanges();

            return RedirectToAction("Index", "CustomerLogin", new { error="Welcome To Ticket Booking App. Please Login to plan your trip."});
        }
    }
}