﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FlightSystemProject.Models;
using System.Web.Security;

namespace FlightSystemProject.Controllers
{
    [AllowAnonymous]
    public class AdminLoginController : Controller
    {
        
    private FlightSystemDbContext context = new FlightSystemDbContext();//ii
        
        // GET: AdminLogin
        public ActionResult Index(string error="")
        {
            if (User.Identity.IsAuthenticated &&
                Session["App"] != null &&
                ((string)Session["App"]).Equals("AdminApp"))
            {
                //FormsAuthentication.RedirectFromLoginPage(User.Identity.Name, false);
                return RedirectToAction("Index", "Booking", new { });
            }
            if (!error.Equals(String.Empty))
            {
                ModelState.AddModelError("", error);
            }
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Index(Admin formAdmin)
        {

            if (!ModelState.IsValid)
            {
                return View(formAdmin);
            }

            var oldAdmin = (from a in context.Admins
                            where a.Username.Equals(formAdmin.Username) && a.Password.Equals(formAdmin.Password)
                            select a).SingleOrDefault();
            if(oldAdmin == null)
            {
                ModelState.AddModelError("", "Invalid Username / Password");
                return View(formAdmin);
            }
            FormsAuthentication.SetAuthCookie(oldAdmin.Username, false);
            Session["App"] = "AdminApp";
            Session["UserId"] = oldAdmin.AdminId;
            //Session["Username"] = oldAdmin.Username;
            return RedirectToAction("Index","FlightManagement");
        }

        [Authorize]
        public ActionResult Logout()
        {
            Session["App"] = null;
            Session["UserId"] = null;
            FormsAuthentication.SignOut();
            //Session["Username"] = null;
            return RedirectToAction("Index");
        }

        public ActionResult test()
        {
            return View();
        }
    }
}