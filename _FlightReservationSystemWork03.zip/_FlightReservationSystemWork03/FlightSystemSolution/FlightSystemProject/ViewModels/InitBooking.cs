﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using FlightSystemProject.Models;
using System.ComponentModel.DataAnnotations;

namespace FlightSystemProject.ViewModels
{
    public class InitBooking
    {
        public InitBooking()
        {
            SelectedFlight = new Flight();
        }
        private int flightId;
        private Flight selectedFlight;

        public int FlightId
        {
            get => flightId; set
            {
                flightId = value;
            }
        }

        [Display(Name = "Number Of Tickets")]
        [Required(ErrorMessage = "Please Enter Number Of Tickets")]
        [Range(1, 5, ErrorMessage = "You can book maximum of 5 tickets")]
        public int NumberOfPassengers { get; set; }

        public Flight SelectedFlight { get => selectedFlight; set => selectedFlight = value; }
    }
}